﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Apllication
{
    public partial class PinInvoer : Form
    {
        public PinInvoer()
        {
            InitializeComponent();
            Cursor.Hide();
            this.Refresh();
            Application.DoEvents();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        public void printStar()
        {
            inputDisplay.AppendText("*");
        }

        public void clear()
        {
            inputDisplay.Clear();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {

        }

        private void confirmButton_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void falsepininfo_Click(object sender, EventArgs e)
        {

        }
    }
}
